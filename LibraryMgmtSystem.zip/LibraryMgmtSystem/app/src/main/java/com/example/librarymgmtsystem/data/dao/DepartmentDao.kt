package com.example.librarymgmtsystem.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Update
import com.example.librarymgmtsystem.data.entities.Department

@Dao
interface DepartmentDao {

    @Insert
    suspend fun insertDept(dept: Department)

    @Update
    suspend fun updateDept(dept: Department)

    @Delete
    suspend fun deleteDept(dept: Department)

}