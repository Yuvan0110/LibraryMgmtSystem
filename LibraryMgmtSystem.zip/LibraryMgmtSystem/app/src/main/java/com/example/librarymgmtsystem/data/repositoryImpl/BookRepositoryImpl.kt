package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.BookAuthor
import com.example.librarymgmtsystem.data.dao.BookCategory
import com.example.librarymgmtsystem.data.dao.BookDao
import com.example.librarymgmtsystem.data.entities.Book
import com.example.librarymgmtsystem.data.repository.BookRepository
import kotlinx.coroutines.flow.Flow

class BookRepositoryImpl(
    private val bookDao: BookDao
): BookRepository {
    override suspend fun insertBook(book: Book) {
        bookDao.insertBook(book)
    }

    override suspend fun updateBook(book: Book) {
        bookDao.updateBook(book)
    }

    override suspend fun deleteBook(book: Book) {
        bookDao.deleteBook(book)
    }

    override fun booksByAuthor(authorId: Int): Flow<List<BookAuthor>> {
        return bookDao.booksByAuthor(authorId)
    }

    override fun booksByCategory(categoryId: Int): Flow<List<BookCategory>> {
        return bookDao.booksByCategory(categoryId)
    }

    override fun getBookByName(bookName: String): Flow<List<Book>> {
        return bookDao.getBookByName(bookName)
    }

}