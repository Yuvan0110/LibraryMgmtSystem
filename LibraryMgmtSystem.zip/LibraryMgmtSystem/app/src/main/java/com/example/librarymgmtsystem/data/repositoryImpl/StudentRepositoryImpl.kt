package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.StudentDao
import com.example.librarymgmtsystem.data.entities.Student
import com.example.librarymgmtsystem.data.repository.StudentRepository

class StudentRepositoryImpl(
    private val studentDao: StudentDao
): StudentRepository {

    override suspend fun insertStudent(student: Student) {
        studentDao.insertStudent(student)
    }

    override suspend fun updateStudent(student: Student) {
        studentDao.updateStudent(student)
    }

    override suspend fun deleteStudent(student: Student) {
        studentDao.deleteStudent(student)
    }

}