package com.example.librarymgmtsystem.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.librarymgmtsystem.data.repository.BorrowDetailsRepository

class BorrowDetailsViewModel(
    private val borrowDetailsRepository: BorrowDetailsRepository
): ViewModel() {



}

class BorrowDetailsViewModelFactory(
    private val borrowDetailsRepository: BorrowDetailsRepository,
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BorrowDetailsViewModel::class.java)) {
            return BorrowDetailsViewModel(borrowDetailsRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
