package com.example.librarymgmtsystem

import android.app.Application
import com.example.librarymgmtsystem.data.AppContainer
import com.example.librarymgmtsystem.data.AppDataContainer

class LibraryMgmtApplication: Application() {

    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppDataContainer(this)
    }

}