package com.example.librarymgmtsystem.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey


@Entity(
    tableName = "student",
    foreignKeys = [
        ForeignKey(
            entity = Department::class,
            parentColumns = ["deptId"],
            childColumns = ["deptId"]
        )
    ]
)
data class Student(
    val studentName: String,
    val studentRollNo: String,
    val year: String,
    val deptId: Int,
    @PrimaryKey(autoGenerate = true)
    val studentId: Int
)
