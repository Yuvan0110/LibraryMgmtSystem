package com.example.librarymgmtsystem.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.librarymgmtsystem.data.entities.Book
import com.example.librarymgmtsystem.data.entities.Category
import kotlinx.coroutines.flow.Flow

data class BookAuthor(
    val bookName: String,
    val authorName: String,
    val noOfCopies: Int
)

data class BookCategory(
    val bookName: String,
    val categoryName: String,
    val noOfCopies: Int
)

@Dao
interface BookDao {

    @Insert
    suspend fun insertBook(book: Book)

    @Update
    suspend fun  updateBook(book: Book)

    @Delete
    suspend fun deleteBook(book: Book)

    @Query("SELECT b.bookName, a.authorName, b.noOfCopies FROM book as b JOIN author as a ON a.authorId = b.authorId WHERE b.authorId = :authorId")
    fun booksByAuthor(authorId: Int): Flow<List<BookAuthor>>

    @Query("SELECT b.bookName, c.categoryName, b.noOfCopies FROM book as b JOIN category as c ON c.categoryId = b.categoryId WHERE b.categoryId = :categoryId")
    fun booksByCategory(categoryId: Int): Flow<List<BookCategory>>

    @Query("SELECT * FROM book WHERE bookName = :bookName")
    fun getBookByName(bookName: String): Flow<List<Book>>

}