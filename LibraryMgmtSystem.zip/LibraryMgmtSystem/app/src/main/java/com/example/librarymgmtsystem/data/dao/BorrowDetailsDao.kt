package com.example.librarymgmtsystem.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import kotlinx.coroutines.flow.Flow

data class BorrowDetailsItem(
    val borrowId: Int,
    val studentId: Int,
    val bookId: Int,
    val borrowDate: String
)

@Dao
interface BorrowDetailsDao{

    @Insert
    suspend fun insertBorrowS(borrowDetails: BorrowDetails)

    @Update
    suspend fun updateBorrow(borrowDetails: BorrowDetails)

    @Delete
    suspend fun deleteBorrow(borrowDetails: BorrowDetails)

    @Query("SELECT borrowId, studentId, bookId, borrowDate FROM borrow_details WHERE isRenewed = 0")
    fun getNonRenewedBooks(): Flow<List<BorrowDetailsItem>>

    @Query("SELECT borrowId, studentId, bookId, borrowDate FROM borrow_details WHERE isRenewed != 0")
    fun getRenewedBooks(): Flow<List<BorrowDetailsItem>>

}