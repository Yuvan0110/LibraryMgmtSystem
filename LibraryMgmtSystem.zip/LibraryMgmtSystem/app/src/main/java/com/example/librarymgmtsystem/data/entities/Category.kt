package com.example.librarymgmtsystem.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "category")
data class Category(
    val categoryName: String,
    @PrimaryKey(autoGenerate = true)
    val categoryId: Int
)