package com.example.librarymgmtsystem.data.repository

import com.example.librarymgmtsystem.data.dao.BorrowDetailsItem
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import kotlinx.coroutines.flow.Flow

interface BorrowDetailsRepository {

    suspend fun insertBorrowS(borrowDetails: BorrowDetails)

    suspend fun updateBorrow(borrowDetails: BorrowDetails)

    suspend fun deleteBorrow(borrowDetails: BorrowDetails)

    fun getNonRenewedBooks(): Flow<List<BorrowDetailsItem>>

    fun getRenewedBooks(): Flow<List<BorrowDetailsItem>>

}