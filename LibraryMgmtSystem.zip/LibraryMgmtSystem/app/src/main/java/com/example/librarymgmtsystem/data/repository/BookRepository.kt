package com.example.librarymgmtsystem.data.repository

import com.example.librarymgmtsystem.data.dao.BookAuthor
import com.example.librarymgmtsystem.data.dao.BookCategory
import com.example.librarymgmtsystem.data.entities.Book
import kotlinx.coroutines.flow.Flow

interface BookRepository {

    suspend fun insertBook(book: Book)

    suspend fun  updateBook(book: Book)

    suspend fun deleteBook(book: Book)

    fun booksByAuthor(authorId: Int): Flow<List<BookAuthor>>

    fun booksByCategory(categoryId: Int): Flow<List<BookCategory>>

    fun getBookByName(bookName: String): Flow<List<Book>>

}