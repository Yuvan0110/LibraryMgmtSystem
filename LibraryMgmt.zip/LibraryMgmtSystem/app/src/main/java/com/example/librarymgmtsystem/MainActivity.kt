package com.example.librarymgmtsystem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.librarymgmtsystem.presentation.design.BookScreen
import com.example.librarymgmtsystem.presentation.design.BorrowDetailsScreen
import com.example.librarymgmtsystem.presentation.viewmodel.BookViewModel
import com.example.librarymgmtsystem.presentation.viewmodel.BookViewModelFactory
import com.example.librarymgmtsystem.presentation.viewmodel.BorrowDetailsViewModel
import com.example.librarymgmtsystem.presentation.viewmodel.BorrowDetailsViewModelFactory
import com.example.librarymgmtsystem.ui.theme.LibraryMgmtSystemTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            val studentRepository = (application as LibraryMgmtApplication).container.studentRepository
            val borrowDetailsRepository = (application as LibraryMgmtApplication).container.borrowDetailsRepository
            val bookDetailsRepository = (application as LibraryMgmtApplication).container.bookRepository

            val borrowDetailsViewModel: BorrowDetailsViewModel = viewModel(factory = BorrowDetailsViewModelFactory(borrowDetailsRepository))
            val bookViewModel: BookViewModel = viewModel(factory = BookViewModelFactory(bookDetailsRepository))

            LibraryMgmtSystemTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
//                    BookScreen(
//                        bookViewModel,
//                        Modifier.padding(innerPadding)
//                    )

                    BorrowDetailsScreen(
                        borrowDetailsViewModel,
                        Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    LibraryMgmtSystemTheme {
        Greeting("Android")
    }
}

/*

Library management  system offline
library card per user name, roll number, unique id, dept, joining year
book enrollment name, author, category, id, copies
book borrow bookId, name, author, borrow( 1 book at a time, renewal)
available books list
available user list
borrowed books list

*/