package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.CategoryDao
import com.example.librarymgmtsystem.data.entities.Category
import com.example.librarymgmtsystem.data.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow

class CategoryRepositoryImpl(
    private val categoryDao: CategoryDao
): CategoryRepository {
    override suspend fun insertCategory(category: Category) {
        categoryDao.insertCategory(category)
    }

    override suspend fun updateCategory(category: Category) {
        categoryDao.updateCategory(category)
    }

    override suspend fun deleteCategory(category: Category) {
        categoryDao.deleteCategory(category)
    }

    override fun getAllCategories(): Flow<List<Category>> {
        return categoryDao.getAllCategories()
    }

}