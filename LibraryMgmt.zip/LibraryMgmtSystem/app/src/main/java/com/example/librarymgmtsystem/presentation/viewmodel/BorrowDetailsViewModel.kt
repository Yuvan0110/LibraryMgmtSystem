package com.example.librarymgmtsystem.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.librarymgmtsystem.data.repository.BorrowDetailsRepository
import androidx.lifecycle.viewModelScope
import com.example.librarymgmtsystem.data.dao.BorrowDetailsItem
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BorrowDetailsViewModel(
    private val borrowDetailsRepository: BorrowDetailsRepository
) : ViewModel() {

    val nonRenewedBooks: StateFlow<List<BorrowDetailsItem>> =
        borrowDetailsRepository.getNonRenewedBooks()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.Lazily,
                initialValue = emptyList()
            )

    val renewedBooks: StateFlow<List<BorrowDetailsItem>> =
        borrowDetailsRepository.getRenewedBooks()
            .stateIn(
                viewModelScope,
                SharingStarted.Lazily,
                emptyList()
            )

    fun insertBorrow(borrowDetails: BorrowDetails) = viewModelScope.launch {
        borrowDetailsRepository.insertBorrowS(borrowDetails)
    }

    fun updateBorrow(borrowDetails: BorrowDetails) = viewModelScope.launch {
        borrowDetailsRepository.updateBorrow(borrowDetails)
    }

    fun deleteBorrow(borrowDetails: BorrowDetails) = viewModelScope.launch {
        borrowDetailsRepository.deleteBorrow(borrowDetails)
    }
}

class BorrowDetailsViewModelFactory(
    private val borrowDetailsRepository: BorrowDetailsRepository,
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BorrowDetailsViewModel::class.java)) {
            return BorrowDetailsViewModel(borrowDetailsRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
