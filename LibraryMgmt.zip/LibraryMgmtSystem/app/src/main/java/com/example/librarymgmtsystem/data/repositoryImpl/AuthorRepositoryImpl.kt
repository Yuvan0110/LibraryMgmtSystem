package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.AuthorDao
import com.example.librarymgmtsystem.data.entities.Author
import com.example.librarymgmtsystem.data.repository.AuthorRepository

class AuthorRepositoryImpl(
    private val authorDao: AuthorDao
): AuthorRepository {

    override suspend fun insertAuthor(author: Author) {
        authorDao.insertAuthor(author)
    }

    override suspend fun updateAuthor(author: Author) {
        authorDao.updateAuthor(author)
    }

    override suspend fun deleteAuthor(author: Author) {
        authorDao.deleteAuthor(author)
    }

}