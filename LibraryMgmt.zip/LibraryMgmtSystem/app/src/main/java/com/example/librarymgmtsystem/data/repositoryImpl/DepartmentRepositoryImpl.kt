package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.DepartmentDao
import com.example.librarymgmtsystem.data.entities.Department
import com.example.librarymgmtsystem.data.repository.DepartmentRepository

class DepartmentRepositoryImpl(
    private val deptDao: DepartmentDao
): DepartmentRepository {

    override suspend fun insertDept(dept: Department) {
        deptDao.insertDept(dept)
    }

    override suspend fun updateDept(dept: Department) {
        deptDao.updateDept(dept)
    }

    override suspend fun deleteDept(dept: Department) {
        deptDao.deleteDept(dept)
    }

}