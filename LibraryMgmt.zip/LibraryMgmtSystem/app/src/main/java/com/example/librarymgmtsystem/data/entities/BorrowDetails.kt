package com.example.librarymgmtsystem.data.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Entity(
    tableName = "borrow_details",
    foreignKeys = [
        ForeignKey(
            entity = Student::class,
            parentColumns = ["studentId"],
            childColumns = ["studentId"]
        ),
        ForeignKey(
            entity = Book::class,
            parentColumns = ["bookId"],
            childColumns = ["bookId"]
        )
    ]
)
data class BorrowDetails(
    val borrowDate: String? = LocalDateTime.now().format(formatter),
    val isRenewed: Boolean? = false,
    val renewDate: String,
    val studentId: Int,
    val bookId: Int,
    @PrimaryKey(autoGenerate = true)
    val borrowId: Int
)

val formatter: DateTimeFormatter? = DateTimeFormatter.ofPattern("dd MMM HH:mm")