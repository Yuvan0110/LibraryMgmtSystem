package com.example.librarymgmtsystem.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.librarymgmtsystem.data.dao.BookAuthor
import com.example.librarymgmtsystem.data.dao.BookCategory
import com.example.librarymgmtsystem.data.entities.Book
import com.example.librarymgmtsystem.data.repository.BookRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class BookViewModel(
    private val bookRepository: BookRepository
) : ViewModel() {

    fun insertBook(book: Book) = viewModelScope.launch {
        bookRepository.insertBook(book)
    }

    fun updateBook(book: Book) = viewModelScope.launch {
        bookRepository.updateBook(book)
    }

    fun deleteBook(book: Book) = viewModelScope.launch {
        bookRepository.deleteBook(book)
    }

    private val _authorId = MutableStateFlow<Int?>(null)
    val booksByAuthor: StateFlow<List<BookAuthor>> =
        _authorId.filterNotNull()
            .flatMapLatest { id -> bookRepository.booksByAuthor(id) }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun loadBooksByAuthor(authorId: Int) {
        _authorId.value = authorId
    }

    private val _categoryId = MutableStateFlow<Int?>(null)
    val booksByCategory: StateFlow<List<BookCategory>> =
        _categoryId.filterNotNull()
            .flatMapLatest { id -> bookRepository.booksByCategory(id) }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun loadBooksByCategory(categoryId: Int) {
        _categoryId.value = categoryId
    }

    private val _bookName = MutableStateFlow<String?>(null)
    val bookByName: StateFlow<List<Book>> =
        _bookName.filterNotNull()
            .flatMapLatest { name -> bookRepository.getBookByName(name) }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun searchBookByName(bookName: String) {
        _bookName.value = bookName
    }
}

class BookViewModelFactory(
    private val bookRepository: BookRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BookViewModel::class.java)) {
            return BookViewModel(bookRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
