package com.example.librarymgmtsystem.data.repository

import com.example.librarymgmtsystem.data.entities.Department

interface DepartmentRepository {

    suspend fun insertDept(dept: Department)

    suspend fun updateDept(dept: Department)

    suspend fun deleteDept(dept: Department)

}