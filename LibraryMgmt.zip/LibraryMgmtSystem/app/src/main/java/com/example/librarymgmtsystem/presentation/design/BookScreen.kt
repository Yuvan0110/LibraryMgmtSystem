package com.example.librarymgmtsystem.presentation.design


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.librarymgmtsystem.data.entities.Book
import com.example.librarymgmtsystem.presentation.viewmodel.BookViewModel

@Composable
fun BookScreen(
    bookViewModel: BookViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    val booksByAuthor = bookViewModel.booksByAuthor.collectAsState()
    val booksByCategory = bookViewModel.booksByCategory.collectAsState()
    val bookByName = bookViewModel.bookByName.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Library Books", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = {
                searchQuery = it
                bookViewModel.searchBookByName(it)
            },
            label = { Text("Search by name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row {
            Button(onClick = { bookViewModel.loadBooksByAuthor(1) }) {
                Text("Load by Author #1")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { bookViewModel.loadBooksByCategory(1) }) {
                Text("Load by Category #1")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        when {
            searchQuery.isNotBlank() -> {
                Text("Search Results:", style = MaterialTheme.typography.titleMedium)
                LazyColumn {
                    items(bookByName.value) { book ->
                        BookItem(book)
                    }
                }
            }
            booksByAuthor.value.isNotEmpty() -> {
                Text("Books by Author:", style = MaterialTheme.typography.titleMedium)
                LazyColumn {
                    items(booksByAuthor.value) { book ->
                        Text("${book.bookName} - ${book.authorName} (${book.noOfCopies} copies)")
                    }
                }
            }
            booksByCategory.value.isNotEmpty() -> {
                Text("Books by Category:", style = MaterialTheme.typography.titleMedium)
                LazyColumn {
                    items(booksByCategory.value) { book ->
                        Text("${book.bookName} - ${book.categoryName} (${book.noOfCopies} copies)")
                    }
                }
            }
        }
    }
}

@Composable
fun BookItem(book: Book) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("Title: ${book.bookName}", style = MaterialTheme.typography.bodyLarge)
            Text("Category ID: ${book.categoryId}")
            Text("Author ID: ${book.authorId}")
            Text("Copies: ${book.noOfCopies}")
        }
    }
}
