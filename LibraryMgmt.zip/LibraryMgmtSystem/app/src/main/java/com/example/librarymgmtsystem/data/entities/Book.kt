package com.example.librarymgmtsystem.data.entities

import android.text.style.ForegroundColorSpan
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey


@Entity(
    tableName = "book",
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["categoryId"],
            childColumns = ["categoryId"]
        ),
        ForeignKey(
            entity = Author::class,
            parentColumns = ["authorId"],
            childColumns = ["authorId"]
        )
    ]
)
data class Book(
    val bookName: String,
    val noOfCopies: Int,
    val categoryId: Int,
    val authorId: Int,
    @PrimaryKey(autoGenerate = true)
    val bookId: Int
)
