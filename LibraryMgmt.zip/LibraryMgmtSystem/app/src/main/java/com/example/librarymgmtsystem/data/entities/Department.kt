package com.example.librarymgmtsystem.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "department")
data class Department(
    val deptName: String,
    @PrimaryKey(autoGenerate = true)
    val deptId: Int
)
