package com.example.librarymgmtsystem.data.repositoryImpl

import com.example.librarymgmtsystem.data.dao.BorrowDetailsDao
import com.example.librarymgmtsystem.data.dao.BorrowDetailsItem
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import com.example.librarymgmtsystem.data.repository.BorrowDetailsRepository
import kotlinx.coroutines.flow.Flow

class BorrowDetailsRepositoryImpl(
    private val borrowDetailsDao: BorrowDetailsDao
): BorrowDetailsRepository {

    override suspend fun insertBorrowS(borrowDetails: BorrowDetails) {
        borrowDetailsDao.insertBorrowS(borrowDetails)
    }

    override suspend fun updateBorrow(borrowDetails: BorrowDetails) {
        borrowDetailsDao.updateBorrow(borrowDetails)
    }

    override suspend fun deleteBorrow(borrowDetails: BorrowDetails) {
        borrowDetailsDao.deleteBorrow(borrowDetails)
    }

    override fun getNonRenewedBooks(): Flow<List<BorrowDetailsItem>> {
        return borrowDetailsDao.getNonRenewedBooks()
    }

    override fun getRenewedBooks(): Flow<List<BorrowDetailsItem>> {
       return borrowDetailsDao.getRenewedBooks()
    }

}