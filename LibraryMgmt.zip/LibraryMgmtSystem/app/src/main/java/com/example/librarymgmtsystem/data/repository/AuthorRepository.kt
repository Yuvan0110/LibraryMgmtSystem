package com.example.librarymgmtsystem.data.repository

import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Update
import com.example.librarymgmtsystem.data.entities.Author

interface AuthorRepository {

    suspend fun insertAuthor(author: Author)

    suspend fun updateAuthor(author: Author)

    suspend fun deleteAuthor(author: Author)

}