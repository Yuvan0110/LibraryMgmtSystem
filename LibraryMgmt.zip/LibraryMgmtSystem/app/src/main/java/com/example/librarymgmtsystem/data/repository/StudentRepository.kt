package com.example.librarymgmtsystem.data.repository

import com.example.librarymgmtsystem.data.entities.Student

interface StudentRepository {

    suspend fun insertStudent(student: Student)

    suspend fun updateStudent(student: Student)

    suspend fun deleteStudent(student: Student)

}