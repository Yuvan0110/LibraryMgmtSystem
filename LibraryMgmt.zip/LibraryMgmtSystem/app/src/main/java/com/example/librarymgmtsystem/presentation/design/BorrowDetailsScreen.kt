package com.example.librarymgmtsystem.presentation.design

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import com.example.librarymgmtsystem.presentation.viewmodel.BorrowDetailsViewModel
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BorrowDetailsScreen(
    borrowDetailsViewModel: BorrowDetailsViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val nonRenewedBooks = borrowDetailsViewModel.nonRenewedBooks.collectAsState()
    val renewedBooks = borrowDetailsViewModel.renewedBooks.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var isUpdateMode by remember { mutableStateOf(false) }
    var editBorrowId by remember { mutableStateOf<Int?>(null) }

    var studentId by remember { mutableStateOf("") }
    var bookId by remember { mutableStateOf("") }
    var markAsRenewed by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Borrowed Books", style = MaterialTheme.typography.titleLarge)

        Spacer(Modifier.height(12.dp))

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) { Text("Non-Renewed") }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) { Text("Renewed") }
        }

        Spacer(Modifier.height(16.dp))

        Box(Modifier.fillMaxSize()) {
            if (selectedTab == 0) {
                LazyColumn {
                    items(nonRenewedBooks.value) { item ->
                        BorrowDetailsCard(
                            borrowId = item.borrowId,
                            studentId = item.studentId,
                            bookId = item.bookId,
                            borrowDate = item.borrowDate,
                            onEdit = {
                                editBorrowId = item.borrowId
                                studentId = item.studentId.toString()
                                bookId = item.bookId.toString()
                                markAsRenewed = false
                                isUpdateMode = true
                                showDialog = true
                            },
                            onDelete = {
                                borrowDetailsViewModel.deleteBorrow(
                                    BorrowDetails(
                                        borrowId = item.borrowId,
                                        studentId = item.studentId,
                                        bookId = item.bookId,
                                        borrowDate = item.borrowDate,
                                        isRenewed = false,
                                        renewDate = ""
                                    )
                                )
                            }
                        )
                    }
                }
            } else {
                LazyColumn {
                    items(renewedBooks.value) { item ->
                        BorrowDetailsCard(
                            borrowId = item.borrowId,
                            studentId = item.studentId,
                            bookId = item.bookId,
                            borrowDate = item.borrowDate,
                            onEdit = {
                                editBorrowId = item.borrowId
                                studentId = item.studentId.toString()
                                bookId = item.bookId.toString()
                                markAsRenewed = true
                                isUpdateMode = true
                                showDialog = true
                            },
                            onDelete = { /* optional delete */ }
                        )
                    }
                }
            }

            FloatingActionButton(
                onClick = {
                    isUpdateMode = false
                    studentId = ""
                    bookId = ""
                    markAsRenewed = false
                    showDialog = true
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) {
                Text("+")
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    val borrowDate = java.time.LocalDateTime.now()
                    val formattedBorrowDate = borrowDate.format(formatter)

                    val borrow = BorrowDetails(
                        borrowId = editBorrowId ?: 0,
                        studentId = studentId.toIntOrNull() ?: 0,
                        bookId = bookId.toIntOrNull() ?: 0,
                        borrowDate = formattedBorrowDate,
                        isRenewed = markAsRenewed,
                        renewDate = if (markAsRenewed) borrowDate.plusDays(7).format(formatter) else ""
                    )

                    if (isUpdateMode) {
                        borrowDetailsViewModel.updateBorrow(borrow)
                    } else {
                        borrowDetailsViewModel.insertBorrow(borrow)
                    }
                    showDialog = false
                }) {
                    Text(if (isUpdateMode) "Update" else "Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel") }
            },
            title = { Text(if (isUpdateMode) "Update Borrow" else "Add Borrow") },
            text = {
                Column {
                    OutlinedTextField(
                        value = studentId,
                        onValueChange = { studentId = it },
                        label = { Text("Student ID") }
                    )
                    OutlinedTextField(
                        value = bookId,
                        onValueChange = { bookId = it },
                        label = { Text("Book ID") }
                    )

                    if (isUpdateMode) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = markAsRenewed,
                                onCheckedChange = { markAsRenewed = it }
                            )
                            Text("Mark as Renewed")
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun BorrowDetailsCard(
    borrowId: Int,
    studentId: Int,
    bookId: Int,
    borrowDate: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Borrow ID: $borrowId")
            Text("Student ID: $studentId")
            Text("Book ID: $bookId")
            Text("Borrow Date: $borrowDate")

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { Text("Edit") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM HH:mm")
