package com.example.librarymgmtsystem.data

import android.content.Context
import com.example.librarymgmtsystem.data.repository.AuthorRepository
import com.example.librarymgmtsystem.data.repository.BookRepository
import com.example.librarymgmtsystem.data.repository.BorrowDetailsRepository
import com.example.librarymgmtsystem.data.repository.CategoryRepository
import com.example.librarymgmtsystem.data.repository.DepartmentRepository
import com.example.librarymgmtsystem.data.repository.StudentRepository
import com.example.librarymgmtsystem.data.repositoryImpl.AuthorRepositoryImpl
import com.example.librarymgmtsystem.data.repositoryImpl.BookRepositoryImpl
import com.example.librarymgmtsystem.data.repositoryImpl.BorrowDetailsRepositoryImpl
import com.example.librarymgmtsystem.data.repositoryImpl.CategoryRepositoryImpl
import com.example.librarymgmtsystem.data.repositoryImpl.DepartmentRepositoryImpl
import com.example.librarymgmtsystem.data.repositoryImpl.StudentRepositoryImpl

interface AppContainer {

    val studentRepository: StudentRepository
    val categoryRepository: CategoryRepository
    val bookRepository: BookRepository
    val borrowDetailsRepository: BorrowDetailsRepository
    val deptRepository: DepartmentRepository
    val authorRepository: AuthorRepository

}

class AppDataContainer(
    private val context: Context
): AppContainer {

    override val studentRepository:  StudentRepository by lazy {
        StudentRepositoryImpl(AppDatabase.Companion.getDatabase(context).studentDao())
    }

    override val authorRepository: AuthorRepository by lazy {
        AuthorRepositoryImpl(AppDatabase.Companion.getDatabase(context).authorDao())
    }

    override val bookRepository: BookRepository by lazy {
        BookRepositoryImpl(AppDatabase.Companion.getDatabase(context).bookDao())
    }

    override val borrowDetailsRepository: BorrowDetailsRepository by lazy {
        BorrowDetailsRepositoryImpl(AppDatabase.Companion.getDatabase(context).borrowDetailsDao())
    }

    override val deptRepository: DepartmentRepository by lazy {
        DepartmentRepositoryImpl(AppDatabase.Companion.getDatabase(context).deptDao())
    }

    override val categoryRepository: CategoryRepository by lazy {
        CategoryRepositoryImpl(AppDatabase.Companion.getDatabase(context).categoryDao())
    }

}