package com.example.librarymgmtsystem.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.librarymgmtsystem.data.dao.AuthorDao
import com.example.librarymgmtsystem.data.dao.BookDao
import com.example.librarymgmtsystem.data.dao.BorrowDetailsDao
import com.example.librarymgmtsystem.data.dao.CategoryDao
import com.example.librarymgmtsystem.data.dao.DepartmentDao
import com.example.librarymgmtsystem.data.dao.StudentDao
import com.example.librarymgmtsystem.data.entities.Author
import com.example.librarymgmtsystem.data.entities.Book
import com.example.librarymgmtsystem.data.entities.BorrowDetails
import com.example.librarymgmtsystem.data.entities.Category
import com.example.librarymgmtsystem.data.entities.Department
import com.example.librarymgmtsystem.data.entities.Student

@Database(
    entities = [Student::class, Book::class, Category::class, Department::class, BorrowDetails::class, Author::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {


    abstract fun studentDao(): StudentDao
    abstract fun bookDao(): BookDao
    abstract fun categoryDao(): CategoryDao
    abstract fun deptDao(): DepartmentDao
    abstract fun borrowDetailsDao(): BorrowDetailsDao
    abstract fun authorDao(): AuthorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "library_mgmt_sys_db"
                )
                    .build()
                    .also {
                        INSTANCE = it
                    }
            }
        }
    }
}