package com.example.librarymgmtsystem.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "author")
data class Author(
    val authorName: String,
    @PrimaryKey(autoGenerate = true)
    val authorId: Int
)
